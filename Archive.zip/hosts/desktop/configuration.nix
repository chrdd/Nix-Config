# Edit this configuration file to define what should be installed on
# your system.  Help is available in the configuration.nix(5) man page
# and in the NixOS manual (accessible by running ‘nixos-help’).
{
  inputs,
  config,
  pkgs,
  lib,
  pkgs-stable,
  winapps,
  ...
}: {
  imports = [
    # Include the results of the hardware scan.
    ./hardware-configuration.nix
    inputs.home-manager.nixosModules.home-manager
  ];

  # Nix Settings

  nix.settings = {
    max-jobs = "auto";
    cores = 4;
    trusted-users = ["root" "octavian"];
    auto-optimise-store = true;
    experimental-features = ["nix-command" "flakes"];
  };

  # Flakes
  # nix = {
  # package = pkgs.nixFlakes;
  # extraOptions = ''experimental-features = nix-command flakes'';
  # };

  #   #Home-ma/home/octavian/Downloads/Untitled Sketch_bb.pngnager
  #   home-manager = {
  #     extraSpecialArgs = { inherit inputs; };
  #     users = {
  #       octavian = import ./home.nix;
  #     };
  #   };

  # Stylix
  # stylix.base16Scheme = "${pkgs.base16-schemes}/share/themes/tokyo-night-dark.yaml";
  # stylix.polarity = "dark";

  # Bootloader
  #boot.loader.grub.efiSupport = true;
  #boot.loader.grub.useOSProber = true;

  boot = {
    tmp.cleanOnBoot = true;
    supportedFilesystems = ["ntfs"];
    loader = {
      efi.canTouchEfiVariables = true;
      grub = {
        device = "nodev";
        efiSupport = true;
        enable = true;
        useOSProber = true;
        timeoutStyle = "menu";
        configurationLimit = 10;
      };
      timeout = 5;
    };
    # CachyOS Kernel
    # kernelPackages = pkgs.cachyosKernels.linuxPackages-cachyos-latest;
    kernelPackages = pkgs.linuxPackages_latest;
    # kernelPackages = pkgs.linuxPackages_6_12;
    extraModulePackages = with config.boot.kernelPackages; [
      v4l2loopback.out
    ];
    # kernelParams = [ "amdgpu.dc=0" ];
    kernelModules = [
      # Virtual Camera
      "v4l2loopback"
      # Virtual Microphone, built-in
      "snd-aloop"
    ];
    initrd.kernelModules = ["amdgpu"];
    extraModprobeConfig = ''options v4l2loopback devices=1 video_nr=1 card_label="Virtual Cam" exclusive_caps=1 '';
  };

  # AMD GPU Settings
  # hardware.amdgpu.amdvlk.enable = true;
  hardware.amdgpu.opencl.enable = true;
  hardware.graphics = {
    enable = true;
    enable32Bit = true;
    extraPackages = with pkgs; [
      libva-vdpau-driver
      libvdpau-va-gl
      rocmPackages.clr.icd # OpenCL support
    ];
    extraPackages32 = with pkgs.pkgsi686Linux; [
      # Remove mesa and libGL from here
    ];
  };

  programs.gamemode.enable = true;
  powerManagement.cpuFreqGovernor = "performance";

  # environment.variables = {
  #   AMD_VULKAN_ICD = "RADV";
  #   RADV_PERFTEST = "gpl";
  # };

  hardware.amdgpu.overdrive.enable = true;
  # hardware.amdgpu.overdrive.ppfeaturemask = "0xfffd7fff"; # only if you want a specific value; omit to use the default
  # boot.kernelParams = [
  #   # "amdgpu.ppfeaturemask=0xffffffff"
  #   # "elevator=none"
  #   # "amd_pstate=active" # enables AMD P-State driver for better CPU freq scaling on Zen CPUs
  #   # "preempt=full" # full kernel preemption for lower input latency
  # ];

  # Enable CPU Microcode Updates
  hardware.cpu.amd.updateMicrocode = true;

  # Enable zramSwap
  zramSwap = {
    enable = true;
    algorithm = "zstd";
    memoryPercent = 30; # 25% of RAM as fast compressed swap
  };

  # LVFS motherboard update
  services.fwupd.enable = true;

  #  #Kernel
  #   boot.kernelPackages = pkgs.linuxPackages_latest;

  #   # Boot packages
  #   boot.extraModulePackages = with config.boot.kernelPackages;
  #   [ v4l2loopback.out xpadneo];

  #     # Activate kernel modules (choose from built-ins and extra ones)
  #   boot.kernelModules = [
  #     # Virtual Camera
  #     "v4l2loopback"
  #     # Virtual Microphone, built-in
  #     "snd-aloop"
  #   ];
  #     # AMD
  #   boot.initrd.kernelModules = ["amdgpu"];
  # boot.extraModprobeConfig = ''
  #   options v4l2loopback devices=1 video_nr=1 card_label="Virtual Cam" exclusive_caps=1
  #  '';

  security.polkit.enable = true;

  #Networking
  networking.hostName = "Orion"; # Define your hostname.

  # networking.wireless.enable = true;  # Enables wireless support via wpa_supplicant.

  # Configure network proxy if necessary
  # networking.proxy.default = "http://user:password@proxy:port/";
  # networking.proxy.noProxy = "127.0.0.1,localhost,internal.domain";

  # Set your time zone.
  time.timeZone = "Europe/Bucharest";

  # Select internationalisation properties.
  i18n.defaultLocale = "en_US.UTF-8";

  i18n.extraLocaleSettings = {
    LC_ADDRESS = "ro_RO.UTF-8";
    LC_IDENTIFICATION = "ro_RO.UTF-8";
    LC_MEASUREMENT = "ro_RO.UTF-8";
    LC_MONETARY = "ro_RO.UTF-8";
    LC_NAME = "ro_RO.UTF-8";
    LC_NUMERIC = "ro_RO.UTF-8";
    LC_PAPER = "ro_RO.UTF-8";
    LC_TELEPHONE = "ro_RO.UTF-8";
    LC_TIME = "ro_RO.UTF-8";
  };
  # Enable Hyprland
  # programs.hyprland = {
  #   enable = true;
  #   package = inputs.hyprland.packages."${pkgs.system}".hyprland;
  #   xwayland.enable = true;
  # };

  # Virtualization
  virtualisation = {
    waydroid.enable = true; # Waydroid
    docker.enable = true; # Docker
  };

  # pkgs.file-roller.enable = true;
  services.gvfs.enable = true; # Mount, trash, and other functionalities
  services.tumbler.enable = true; # Thumbnail support for images

  services.xserver.videoDrivers = ["modesetting"];

  # Media keys
  services.actkbd = {
    enable = true;
    bindings = [
      #{ keys = [ 115 ]; events = [ "key" ]; command = "/run/current-system/sw/bin/runuser -l octavian -c 'amixer set Master 5%+'"; }
      {
        keys = [115];
        events = ["key"];
        command = "${pkgs.alsa-utils}/bin/amixer -q set Master 5%+";
      }
      {
        keys = [114];
        events = ["key"];
        command = "${pkgs.alsa-utils}/bin/amixer -q set Master 5%-";
      }
      {
        keys = [113];
        events = ["key"];
        command = "${pkgs.alsa-utils}/bin/amixer -q set Master toggle";
      }
    ];
  };

  environment.sessionVariables = {
    # WLR_NO_HARDWARE_CURSORS = "1";
    NIXOS_OZONE_WL = "1";
    # LIBGL_DEBUG = "verbose";
    EGL_PLATFORM = "wayland";
  };

  #Nfs
  # fileSystems."/mnt/share/media" = {
  #   device = "192.168.3.8:/mnt/Media/Media";
  #   fsType = "nfs";
  #   options = ["rw" "nconnect=16" "x-systemd.automount" "noauto"];
  # };

  # Autostart polkit_gnome
  # systemd = {
  #   user.services.polkit-gnome-authentication-agent-1 = {
  #     description = "polkit-gnome-authentication-agent-1";
  #     wantedBy = ["graphical-session.target"];
  #     wants = ["graphical-session.target"];
  #     after = ["graphical-session.target"];
  #     serviceConfig = {
  #       Type = "simple";
  #       ExecStart = "${pkgs.polkit_gnome}/libexec/polkit-gnome-authentication-agent-1";
  #       Restart = "on-failure";
  #       RestartSec = 1;
  #       TimeoutStopSec = 10;
  #     };
  #   };
  # };

  #Load Nvidia drivers
  #services.xserver.videoDrivers = ["nvidia"]; # or "nvidiaLegacy470 etc.
  #services.xserver.displayManager.gdm = {
  #enable = true;
  #nvidiaWayland = true;
  #};
  # X11
  services.xserver = {
    enable = true;
    # desktopManager.gnome.enable = true;
    # Configure keymap in X11
    xkb = {
      variant = "";
      layout = "us";
    };
  };
  services.desktopManager.plasma6.enable = true;
  # services.xserver.enable = true;
  #services.xserver.displayManager.sddm.enable = true;
  # services.xserver.desktopManager.gnome.enable = true;

  # SSD Optimisation
  # services.fstrim.enable = true;
  boot.initrd.luks.devices."crypted" = {
    allowDiscards = true; # let TRIM pass through to the SSD
    bypassWorkqueues = true; # skips dm-crypt's crypto workqueues — meaningful IOPS win on NVMe
  };
  # Enable the KDE Plasma Desktop Environment.
  #services.xserver.displayManager.sddm.wayland.enable = true;

  fileSystems."/".options = ["compress=zstd" "noatime" "space_cache=v2"];
  fileSystems."/home".options = ["compress=zstd" "noatime" "space_cache=v2"];
  fileSystems."/nix".options = ["compress=zstd" "noatime" "space_cache=v2"];
  fileSystems."/var/log".options = ["compress=zstd" "noatime" "space_cache=v2"];

  services.btrfs.autoScrub = {
    enable = true;
    fileSystems = ["/"];
  };

  fileSystems."/mnt/ssd" = {
    device = "/dev/disk/by-uuid/001f7666-11d4-42c9-a9a1-b22610c51cc6";
    fsType = "ext4";
    options = ["nofail"];
  };

  fileSystems."/mnt/games" = {
    device = "/dev/disk/by-uuid/1140de40-e759-4b96-aec3-8db0b0c98c37";
    fsType = "ext4";
    options = ["nofail"];
  };

  #  Display Manager
  services.displayManager = {
    defaultSession = "plasma";
    sddm.enable = true;
    sddm.theme = "sddm-astronaut-theme";
    sddm.wayland.enable = true;
  };
  #  services.displayManager.sddm.wayland.enable = true;
  #  services.displayManager.sddm.enable = true;
  #  #Default session
  #  services.displayManager.defaultSession = "plasma";

  #  Nix Helper (nh)

  # Sway
  #programs.sway = {
  #  enable = true;
  #  wrapperFeatures.gtk = true;
  #};
  # Swaylock
  #programs.swaylock = {
  #  enable= true;
  #};
  # Swaylock fix
  # security.pam.services.swaylock = {};
  #services.xserver.desktopManager.plasma5.enable = true;

  # services.xserver.xkb.variant = "";
  # services.xserver.xkb.layout = "us";

  # Enable CUPS to print documents.
  services.printing.enable = true;

  # Enable sound with pipewire.
  # sound.enable = true;
  services.pulseaudio.enable = false;
  security.rtkit.enable = true;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;
    pulse.enable = true;
    # If you want to use JACK applications, uncomment this
    jack.enable = true;

    # use the example session manager (no others are packaged yet so this is enabled by default,
    # no need to redefine it in your config for now)
    #media-session.enable = true;
  };
  services.pipewire.wireplumber.extraConfig."99-disable-suspend" = {
    "monitor.alsa.rules" = [
      {
        matches = [
          {"node.name" = "~alsa_input.*";}
          {"node.name" = "~alsa_output.*";}
        ];
        actions.update-props = {
          "session.suspend-timeout-seconds" = 0;
        };
      }
    ];
  };

  # Enable touchpad support (enabled default in most desktopManager).
  services.libinput.enable = true;

  # Define a user account. Don't forget to set a password with ‘passwd’.
  users.users.octavian = {
    isNormalUser = true;
    description = "octavian";
    extraGroups = ["networkmanager" "wheel" "audio" "vboxusers" "dialout" "scanner" "lp" "docker"];
    packages = with pkgs; [
      # firefox
      # kdePackages.kate
      #  thunderbird
    ];
    # openssh.authorizedKeys.keys = [ "ssh-rsa AAAAB3NzaC1yc2etc/etc/etcjwrsh8e596z6J0l7 example@host" "ssh-ed25519 AAAAC3NzaCetcetera/etceteraJZMfk3QPfQ foo@bar" ];
  };

  programs.ssh.askPassword = lib.mkForce "${pkgs.kdePackages.ksshaskpass}/bin/ksshaskpass";

  hardware.enableRedistributableFirmware = true;

  # hardware.xpadneo.enable = true;
  # hardware.steam-hardware.enable = true;

  # Allow unfree packages
  nixpkgs.config = {
    allowUnfree = pkgs.lib.mkForce true;
    # allowInsecure = true;
    # packageOverrides = pkgs: {
    # unstable = import <nixos-unstable> { config = { allowUnfree = true; }; };
    # };
    permittedInsecurePackages = [
      "electron-39.8.10"
      "electron-40.10.5"
    ];
  };
  # services.avahi.enable = true;
  # services.avahi.publish.enable = true;
  # services.avahi.publish.userServices = true;

  # SANE scanner
  # hardware.sane = {
  #   enable = true;
  #   extraBackends = [pkgs.sane-airscan];
  # };

  # hardware.sane.drivers.scanSnap.enable = true;
  # environment.etc."sane/gt68xx/PS1fw.usb".source = /home/octavian/Documents/sane/gt68xx/PS1fw.usb;

  #TeamViewer
  services.teamviewer.enable = true;

  # Samba
  # services.sambaClient.enable = true;

  # services.gnome.gnome-remote-desktop.enable = true;

  # Capping Memory
  systemd.services.nix-daemon.serviceConfig = {
    MemoryHigh = "16G"; # soft: kernel starts reclaiming/throttling here
    MemoryMax = "20G"; # hard: OOM-killer kills processes in this cgroup only
  };

  # Fonts
  fonts.packages = with pkgs; [
    fira-code
    # jetbrains-mono
    meslo-lgs-nf
    dejavu_fonts
    liberation_ttf
    font-awesome
    hackgen-nf-font
    udev-gothic-nf
    source-han-sans
    source-han-serif
  ];

  nixpkgs.overlays = [
    # inputs.millennium.overlays.default
    # (final: prev: {
    #   winboat = prev.winboat.overrideAttrs (old: {
    #     "guest-server" = old."guest-server".overrideAttrs (gsOld: {
    #       nativeBuildInputs = map (
    #         dep:
    #           if dep.pname or "" == "go"
    #           then prev.go_1_26
    #           else dep
    #       ) (gsOld.nativeBuildInputs or []);
    #     });
    #   });
    # })
  ];

  # Enable nix-ld to run unpatched Linux binaries
  programs.nix-ld.enable = true;

  # Define the shared libraries that unpatched binaries will have access to
  programs.nix-ld.libraries = with pkgs; [
    stdenv.cc.cc.lib
    zlib
    glib
    curl
    openssl

    # Required for graphical interfaces (X11 / Wayland / GL)
    xorg.libX11
    xorg.libXrandr
    xorg.libXext
    xorg.libXcursor
    xorg.libXi
    xorg.libXfixes
    libGL
    vulkan-loader
    wayland

    # Required for some hardware probers / desktop standards
    alsa-lib
    dbus
    fontconfig
    freetype
    libxkbcommon
    udev
  ];

  environment.systemPackages = with pkgs; [
    #  vim # Do not forget to add an editor to edit configuration.nix! The Nano editor is also installed by default.
    # docker-compose
    # rofi
    # glfw-wayland
    # kdePackages.xwaylandvideobridge
    # openssl
    # papirus-icon-theme
    # rocmPackages.rocm-smi
    # tesseract4
    # linuxKernel.packages.linux_zen.xpadneo
    # bottles
    # gnome-keyring
    # inputs.self.packages.${pkgs.system}.shadps4-0_6_0
    # lutris
    # mailspring
    # pkgs-stable.bambu-studio
    # pkgs-stable.orca-slicer
    # pkgs.polkit_gnome
    # todoist-electron
    # zotero
    signal-desktop
    feishin
    picard
    alacritty
    alejandra
    alsa-utils
    anki
    ansible
    anydesk
    bitwarden-desktop
    bottom
    btop-rocm
    caligula
    cargo
    clinfo
    cmake
    deskreen
    discord
    dos2unix
    dysk
    easyeffects
    expat
    f3
    fastfetch
    ffmpeg
    ffmpegthumbnailer
    filezilla
    flameshot
    floorp-bin
    fluent-reader
    freerdp
    fzf
    gcc
    gh
    ghostty
    git-crypt
    glew
    glfw
    glfw3-minecraft
    gnumake
    gogdl
    gparted
    grim
    grimblast
    hackgen-nf-font
    heroic
    imagemagick
    inputs.helium.packages.${system}.default
    inputs.zen-browser.packages."${system}".default
    itch
    jamesdsp
    jdk17
    jq
    kdePackages.kasts
    kdePackages.krdp
    kdePackages.krfb
    kdePackages.kwalletmanager
    kdePackages.plasma-browser-integration
    kdePackages.qtmultimedia
    kdePackages.qtwayland
    kitty
    libGL
    libglibutil
    libGLU
    libglvnd
    libnotify
    libva
    libva-utils
    libvdpau
    libXrandr
    localsend
    lsd
    mesa
    mesa-demos
    meson
    pkgs-stable.moonlight-qt
    mpv
    ncdu
    nix-diff
    nix-output-monitor
    nix-tree
    nodejs
    nota
    ntfs3g
    nvd
    nvtopPackages.amd
    nwg-look
    obs-studio
    obsidian
    ocamlPackages.ssl
    openssl
    protonmail-desktop
    fetch
    # openssl_3
    # openssl_legacy
    pamixer
    papirus-icon-theme
    pavucontrol
    pineflash
    pkg-config
    pkgs-stable.freecad
    pkgs.cifs-utils
    pkgs.deluged
    pkgs.oh-my-zsh
    pkgs.sane-backends
    pkgs.sx
    pkgs.wayvnc
    pkgs.xorg.xinit
    pkgs.zsh-completions
    pkgs.zsh-powerlevel10k
    pkgs.zsh-syntax-highlighting
    playerctl
    plex-desktop
    plexamp
    postman
    protonup-qt
    python3
    qbittorrent-enhanced
    qemu
    qt5.qtwayland
    quickemu
    ranger
    rivalcfg
    rpi-imager
    samba
    scrcpy
    sddm-astronaut
    signal-desktop
    slurp
    smartmontools
    source-han-sans
    source-han-serif
    speedtest-cli
    sshfs
    starship
    steam-run
    syncthing
    tautulli
    thunderbird
    ticktick
    tldr
    tor
    tor-browser
    tumbler
    udev-gothic-nf
    unrar
    unzip
    vdpauinfo
    viewnior
    virtio-win
    vivaldi
    vlc
    vulkan-tools
    wayvnc
    weylus
    # wf-recorder
    wget
    winboat
    winetricks
    wineWow64Packages.waylandFull
    wireplumber
    wl-clipboard
    wlogout
    wlr-randr
    wlroots
    xbindkeys
    xdg-desktop-portal-gtk
    xdotool
    xwayland
    yad
    yt-dlp
    zapzap
    zoxide
    zed-editor
    #   mesonFlags = oldAttrs.mesonFlags ++ ["-Dexperimental=true"];
    # (pkgs.waybar.overrideAttrs (oldAttrs: {
    # }))
    # pkgs.waybar
    # xdg-desktop-portal-hyprland
    # winapps.packages."${system}".winapps
    # winapps.packages."${system}".winapps-launcher # optional
    #  wget
    # aquamarine
    # arduino-ide
    # arduino-ide
    # colloid-gtk-theme
    # colloid-icon-theme
    # colloid-kde
    # libsForQt5.libkscreen
    # audacity
    # blender
    # cudaPackages.nvidia_driver
    # davinci-resolve
    # droidcam
    # fish
    # flatpak
    # git
    # github-desktop
    # gnome-remote-desktop
    # guacamole-server
    # hyprland
    # jdk8
    # jetbrains.idea-ultimate
    # kdePackages.kdenlive
    # kodi-wayland
    # lact
    # lact
    # libGLU
    # libglvnd
    # libreoffice
    # libsForQt5.kdeconnect-kde
    # masterpdfeditor
    # mathpix-snipping-tool
    # maven
    # mesa
    # modelsim
    # neatvnc
    # nerd-fonts
    # net-snmp
    # nexusmods-app
    # nixd
    # nordic
    # ollama-rocm
    # parsec-bin
    # pkgs.dunst
    # pkgs.nautilus
    # pkgs.nemo-with-extensions
    # plasma5Packages.kdeconnect-kde
    # prismlauncher
    # python311
    # rquickshare
    # rustc
    # rustup
    # steam
    # sublime
    # swaylock
    # tailscale
    # tailscale
    # tailscale
    # tmux
    # v4l2loopback
    # vencord
    # vencord
    # virtualbox
    # vscode
    # vscodium
    # wayvnc
    # whatsie
    # wl-paste
    # xdg-dekstop-portal-kde
    # youtube-music
    # z-lua
    # zathura
    # zoxide
    #btop
    #cmake
    #glu
    #gnumake
    #Java
    #libstdcxx5
    #ninja
    #pkgs.zsh-history-substring-search
    #poetry
    #privateGPT dependencies
    #stdenv.cc.cc.lib
    #Sunshine
    #themes
    # tigervnc
    #v4l2loopback
    #vulkan
    #zabbix.agent
    #zabbix.web
    #zabbixctl
  ];

  # ZSH
  # programs.fish.enable = true;
  # Insecure packages
  # nixpkgs.config.permittedInsecurePackages = ["electron-25.9.0" "electron-33.4.11"];

  # XDG desktop portals
  # xdg.portal.enable = true;
  # xdg.portal.extraPortals = [
  # ];
  # xdg.portal.xdgOpenUsePortal = true;

  # systemd.user.services.xdg-desktop-portal-gtk = {
  #   wantedBy = ["xdg-desktop-portal.service"];
  #   before = ["xdg-desktop-portal.service"];
  # };

  #VNC
  # systemd.services.krfb-virtualmonitor = {
  # description = "Virtual Monitor for Wireless Display";
  # wantedBy = [ "multi-user.target" ]; # Ensure it runs at boot
  # after = [ "network.target" "display-manager.service" ]; # Start after network and display manager

  # serviceConfig = {
  #   ExecStart = "/run/current-system/sw/bin/krfb-virtualmonitor --name WirelessDisplay --resolution 2048x1536 --password deadbeef --port 5900";
  #   Restart = "always"; # Restart if it crashes
  #   User = "octavian"; # Replace with your actual username
  #   Environment = "DISPLAY=:0"; # Ensures it runs in the graphical session
  # };
  # };

  #AMD
  # systemd.packages = with pkgs; [lact];
  # systemd.services.lactd.wantedBy = ["multi-user.target"];
  #KDEConnect
  programs.kdeconnect.enable = true;

  #UEFI Firmware support for virtual machines
  systemd.tmpfiles.rules = ["L+ /var/lib/qemu/firmware - - - - ${pkgs.qemu}/share/qemu/firmware"];

  services.lact.enable = true;

  services.colord.enable = true;

  # hardware.amdgpu.amdvlk = {
  #   # enable = true;
  #   support32Bit.enable = true;
  # };
  # systemd.tmpfiles.rules = [
  #   "L+    /opt/rocm/hip   -    -    -     -    ${pkgs.rocmPackages_5.clr}"
  # ];

  #Some programs need SUID wrappers, can be configured further or are
  # started in user sessions.
  # programs.mtr.enable = true;
  programs.gnupg.agent = {
    enable = true;
    enableSSHSupport = true;
  };

  # List services that you want to enable:

  # programs.adb.enable = true;
  networking.firewall.allowedTCPPorts = [8000];
  networking.firewall.allowedUDPPorts = [8000];
  # Or disable the firewall altogether.
  # networking.firewall.enable = false;

  # This value determines the NixOS release from which the default
  # settings for stateful data, like file locations and database versions
  # on your system were taken. It‘s perfectly fine and recommended to leave
  # this value at the release version of the first install of this system.
  # Before changing this value read the documentation for this option
  # (e.g. man configuration.nix or on https://nixos.org/nixos/options.html).
  system.stateVersion = "23.11"; # Did you read the comment?
}
